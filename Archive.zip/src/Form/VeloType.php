<?php

namespace App\Form;

use App\Entity\Type;
use App\Entity\Velo;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class VeloType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom',  TextType::class, array(
				'label' => "Nom du Vélo: "
			))
            ->add('prixHT')

            ->add('type', EntityType::class, array(
				'class' => Type::class,
				'choice_label' =>'libelleType',
				'required' => true,
				'label' => 'Type',
				'multiple' => false
			))
			->add('imageFile', FileType::class, array(
				'required' => false
			))
		;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Velo::class,
        ]);
    }
}
