<?php

namespace App\Controller;

use App\Entity\Panier;
use App\Repository\VeloRepository;
use http\Client\Curl\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PanierController
 * @package App\Controller
 */
class PanierController extends AbstractController
{
    /**
     * @Route("/panier", name="panier")
     */
    public function index(SessionInterface $session, VeloRepository $veloRepository)
    {
        $p= new  Panier();
        $total=0;
        $panier=$session->get('panier',[]);


        $panierWithData=[];

        foreach ($panier as $id => $quantity){

            $panierWithData []= [
                'product'=> $veloRepository->find($id),
                'quantity'=>$quantity

            ];
            $total=0;



            foreach ($panierWithData as $item){
                $totalItem= $item['product']->getPrixHT() * $item['quantity'];

                $total += $totalItem;
            }

            dump($panierWithData);
            $session->set('panier',$panierWithData);
            dump($session->set('panier',$panierWithData));
        }
        if (!empty($panier)){


            /*			foreach ($panierWithData as $data){

                            $panierWithData=$data;
                            $nom=$data['product']->getNom();
                            $prixHT=$data['product']->getPrixHT();
                            $prixTTC=$prixHT*1.20;
                            $quantite=intval($data['quantity']);
                            $IdUser=$this->getUser()->getId();

                            $p->setNom($nom);
                            $p->setPrixHT($prixHT);
                            $p->setPrixTTC($prixTTC);
                            $p->setQuantite($quantite);
                            $p->setUser($IdUser);


                        }*/




            return $this->render('panier/index.html.twig', [
                'controller_name' => 'PanierController',
                'items'=>$panierWithData,
                'title'=>"total:",
                'bouton'=>"Continuer mes choix",
                'total'=>$total,
                'euro' => '€'
            ]);
        }
        else{
            return $this->render('panier/index.html.twig', [
                'controller_name' => 'PanierController',
                'items'=>$panierWithData,
                'title'=> "",
                'bouton'=>"Trouver une location",
                'total'=>"",
                'euro'=>"Oups c'est vide!"
            ]);
        }
    }

    /**
     * @Route("/panier/add/{id}", name="panier_add")
     */
    public function add($id,SessionInterface $session):Response
    {


        $panier=$session->get('panier',[]);

        if (!empty($panier[$id])){
            $panier[$id]++;
        }else{
            $panier[$id]=1;
        }


        $session->set('panier',$panier);
        return $this->redirectToRoute('panier');
    }


    /**
     * @Route("/panier/sub/{id}", name="panier_sub")
     */
    public function sub($id,SessionInterface $session):Response
    {

        $panier=$session->get('panier',[]);

        if (!empty($panier[$id])){
            $panier[$id]--;
        }elseif($panier[$id]>=0){

            //	}
            //if ($panier[$id]=0){

            return $this->redirectToRoute('panier');
        }


        //dd($session);
        $session->set('panier',$panier);
        return $this->redirectToRoute('panier');
    }


    /**
     * @Route("/panier/remove/{id}", name="panier_remove")
     */
    public function remove($id, SessionInterface $session)
    {
        $panier=$session->get('panier',[]);
        if (!empty($panier[$id])){
            unset($panier[$id]);
        }
        $session->set('panier', $panier);

        return $this->redirectToRoute('panier');
    }

    /**
     * @Route("/panier/confirm", name="panier_confirm")
     */
    public function confirm( SessionInterface $session, VeloRepository $veloRepository)
    {
        $panier=$session->get('panier',[]);
        //dump($panier);

        $p = new Panier();
        $p->setNom();
        $p->setPrixHT();
        $p->setQuantite($panier[]);
        $p->setUser($this->getUser()->getId());

        //dd($veloRepository->find());
    }
}
