<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PanierRepository")
 */
class Panier
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=150)
     */
    private $nom;

    /**
     * @ORM\Column(type="integer")
     */
    private $PrixHT;

    /**
     * @ORM\Column(type="integer")
     */
    private $PrixTTC;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $quantite;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $IdUser;

	public function getUser(): ?int
	{
		return $this->IdUser;
	}

	public function setUser(int $IdUser): self
	{
		$this->IdUser=$IdUser;

		return $this;
	}

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrixHT(): ?int
    {
        return $this->PrixHT;
    }

    public function setPrixHT(int $PrixHT): self
    {
        $this->PrixHT = $PrixHT;

        return $this;
    }

    public function getPrixTTC(): ?int
    {
        return $this->PrixTTC;
    }

    public function setPrixTTC(int $PrixTTC): self
    {
        $this->PrixTTC = $PrixTTC;

        return $this;
    }

    public function getQuantite()
	{
		return $this->quantite;
	}

	public function setQuantite(int $quantite):self
	{
		$this->quantite=$quantite;
		return $this;
	}
}
