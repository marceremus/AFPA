<?php

namespace App\Entity;

use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Exception;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="App\Repository\VeloRepository")
 * @Vich\Uploadable()
 */
class Velo
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=155)
     */
    private $nom;

    /**
     * @ORM\Column(type="integer")
     */
    private $prixHT;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Type", inversedBy="velos")
     * @ORM\JoinColumn(nullable=false)
     */
    private $type;


	/**
	 * @ORM\Column(type="datetime")
	 * @var null|DateTime
	 */
	private $updated_at;


	/**
	 * @var string|null
	 * @ORM\Column(type="string", length=255)
	 */
	private $filename;

	/**
	 * @var File|null
	 * @Assert\Image(mimeTypes={"image/jpeg", "image/jpg", "image/png"})
	 * @Vich\UploadableField(mapping="product_image", fileNameProperty="filename")
	 *
	 */
	private $imageFile;

	/**
	 * @return string|null
	 */
	public function getFilename(): ?string
	{
		return $this->filename;
	}

	/**
	 * @param string|null $filename
	 * @return Velo
	 */
	public function setFilename(?string $filename): Velo
	{
		$this->filename = $filename;
		return $this;
	}


	/**
	 * @return int|null
	 */
	public function getId(): ?int
    {
        return $this->id;
    }

	/**
	 * @return string|null
	 */
	public function getNom(): ?string
    {
        return $this->nom;
    }

	/**
	 * @param string $nom
	 * @return $this
	 */
	public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

	/**
	 * @return int|null
	 */
	public function getPrixHT(): ?int
    {
        return $this->prixHT;
    }

	/**
	 * @param int $prixHT
	 * @return $this
	 */
	public function setPrixHT(int $prixHT): self
    {
        $this->prixHT = $prixHT;

        return $this;
    }

	/**
	 * @return Type|null
	 */
	public function getType(): ?Type
    {
        return $this->type;
    }

	/**
	 * @param Type|null $type
	 * @return $this
	 */
	public function setType(?Type $type): self
    {
        $this->type = $type;

        return $this;
    }

	/**
	 * @return File|null
	 */
	public function getImageFile(): ?File
	{
		return $this->imageFile;
	}


	/**
	 * @param File|null $imageFile
	 * @throws \Exception
	 */
	public function setImageFile(?File $imageFile ): void {
		$this->imageFile = $imageFile;
		if($this->imageFile instanceof UploadedFile){
			$this->updated_at = new \DateTime('now');
		}
		//return $this;
	}

	/**
	 * @return DateTime|null
	 */
	public function getUpdatedAt(): ?DateTime
	{
		return $this->updated_at;
	}

	/**
	 * @param DateTime|null $updated_at
	 */
	public function setUpdatedAt(?DateTime $updated_at): void
	{
		$this->updated_at = $updated_at;
	}

}
