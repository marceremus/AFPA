<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TypeRepository")
 */
class Type
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=155)
     */
    private $libelleType;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Velo", mappedBy="type")
     */
    private $velos;

    public function __construct()
    {
        $this->velos = new ArrayCollection();
    }



    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelleType(): ?string
    {
        return $this->libelleType;
    }

    public function setLibelleType(string $libelleType): self
    {
        $this->libelleType = $libelleType;

        return $this;
    }

    /**
     * @return Collection|Velo[]
     */
    public function getVelos(): Collection
    {
        return $this->velos;
    }

    public function addVelo(Velo $velo): self
    {
        if (!$this->velos->contains($velo)) {
            $this->velos[] = $velo;
            $velo->setType($this);
        }

        return $this;
    }

    public function removeVelo(Velo $velo): self
    {
        if ($this->velos->contains($velo)) {
            $this->velos->removeElement($velo);
            // set the owning side to null (unless already changed)
            if ($velo->getType() === $this) {
                $velo->setType(null);
            }
        }

        return $this;
    }


}
