<?php

define('LOCALHOST', 'localhost');
define('DBNAME', 'vehicule');
define('DBID', 'root');
define('DBMDP', 'root');

